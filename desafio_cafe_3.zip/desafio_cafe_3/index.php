<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Pokémon</title>
    <link rel="stylesheet" href="../desafio_cafe_3/css/pokemom.css">
</head>
<body>
    <h1>Meus Pokémon Favoritos</h1>

    <?php
        
        require_once 'service_web_pokemon.php'; 
    ?>

</body>
</html>