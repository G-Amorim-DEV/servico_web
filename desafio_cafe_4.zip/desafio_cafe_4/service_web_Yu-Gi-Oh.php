<?php

$cartas = [
    'Exodia the Forbidden One',
    'Right Arm of the Forbidden One',
    'Left Arm of the Forbidden One',
    'Right Leg of the Forbidden One',
    'Left Leg of the Forbidden One'
];

foreach ($cartas as $nome) {

    $url = "https://db.ygoprodeck.com/api/v7/cardinfo.php?name=" . urlencode($nome);

    $resposta = @file_get_contents($url); 


    $dados = json_decode($resposta, true);

 
        $card = $dados['data'][0]; 
        
        // Extrai os dados, usando htmlspecialchars e nl2br para formatação e segurança
        $nome_card = htmlspecialchars($card['name']); 
        $descricao = nl2br(htmlspecialchars($card['desc']));
        $imagem_url = htmlspecialchars($card['card_images'][0]['image_url']);
        
    
        echo "<div class='carta'>";
        echo "    <h2 class='carta-nome'>" . $nome_card . "</h2>";
            
        echo "    <div class='carta-imagem'>";
        echo "        <img src='$imagem_url' alt='Imagem de $nome_card'>";
        echo "    </div>";
            
        echo "    <div class='carta-descricao'>";
        echo "        <p>$descricao</p>"; 
        echo "    </div>";
            
        echo "</div>"; 
}
?>