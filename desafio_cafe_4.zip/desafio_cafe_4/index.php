<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Cartas Yu-Gi-Oh! (Exodia)</title>
    <link rel="stylesheet" href="../desafio_cafe_4/css/Yu-Gi-Oh.css"> 
</head>
<body>
    <h1>As Cinco Partes de Exodia</h1>

    <div class="container-cartas">
        <?php
            require_once "../desafio_cafe_4/service_web_Yu-Gi-Oh.php"; 
        ?>
    </div>
</body>
</html>